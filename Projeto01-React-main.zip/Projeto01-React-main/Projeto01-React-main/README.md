# Projeto01-React
Meu primero projeto em React, exibindo uma curta mensagem de texto na tela
